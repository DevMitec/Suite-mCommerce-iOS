//
//  BeanTokenizeResponse.h
//  SuiteMCommerce
//
//  Created by Pruebas MIT Desarrollo on 19/02/16.
//  Copyright © 2016 Mercadotecnia Ideas y Tecnología. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BeanTokenizeResponse : NSObject

@property (strong, nonatomic) NSString *token;

@end
