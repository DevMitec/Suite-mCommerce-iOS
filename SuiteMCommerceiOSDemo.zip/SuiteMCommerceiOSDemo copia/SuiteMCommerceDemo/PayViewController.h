//
//  ViewController.h
//  SuiteMCommerceDemo
//
//  Created by Pruebas MIT Desarrollo on 15/02/16.
//  Copyright © 2016 Mercadotecnia Ideas y Tecnología. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <SuiteMCommerce/SuiteMCommerce.h>
#import "PaymentResultViewController.h"
#import "DatosDePrueba.h"

@interface PayViewController : UIViewController <SuiteControllerDelegate>

@property (weak, nonatomic) IBOutlet UITextField *textFieldAmount;
@property (weak, nonatomic) IBOutlet UITextField *textFieldReference;
@property (weak, nonatomic) IBOutlet UISegmentedControl *SegmentedControlPaymentType;
@property (weak, nonatomic) IBOutlet UISegmentedControl *SegmentedControlCurrency;

- (IBAction)btnPay:(id)sender;
- (IBAction)btnBack:(id)sender;

@end