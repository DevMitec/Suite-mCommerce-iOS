//
//  PaymentResultViewController.m
//  SuiteMCommerceDemo
//
//  Created by Pruebas MIT Desarrollo on 16/02/16.
//  Copyright © 2016 Mercadotecnia Ideas y Tecnología. All rights reserved.
//

#import "PaymentResultViewController.h"

@implementation PaymentResultViewController
@synthesize response;

-(void)viewDidLoad{
    
    [_labelReference    setText:[self obtenDatoDelXmlConElTag:@"referencia" delXml:response]];
    [_labelResponse     setText:[self obtenDatoDelXmlConElTag:@"response" delXml:response]];
    [_labelAuth         setText:[self obtenDatoDelXmlConElTag:@"aut" delXml:response]];
    [_labelCcName       setText:[self obtenDatoDelXmlConElTag:@"ccName" delXml:response]];
    [_labelCcNum        setText:[self obtenDatoDelXmlConElTag:@"ccNum" delXml:response]];
    [_labelCcType       setText:[self obtenDatoDelXmlConElTag:@"amount" delXml:response]];
    [_labelAmount       setText:[self obtenDatoDelXmlConElTag:@"type" delXml:response]];
    [_labelError        setText:[self obtenDatoDelXmlConElTag:@"error" delXml:response]];
}

- (IBAction)btnBack:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (NSString *) obtenDatoDelXmlConElTag:(NSString *)elTag delXml:(NSString *)elXml{
    NSString * subString = @"";
    @try {
        NSString * tagInicio=@"";
        tagInicio=[tagInicio stringByAppendingString:@"<"];
        tagInicio=[tagInicio stringByAppendingString:elTag];
        tagInicio=[tagInicio stringByAppendingString:@">"];
        
        NSString * tagFin=@"";
        tagFin=[tagFin stringByAppendingString:@"</"];
        tagFin=[tagFin stringByAppendingString:elTag];
        tagFin=[tagFin stringByAppendingString:@">"];
        
        NSRange startRange = [elXml rangeOfString:tagInicio];
        NSRange endRange = [elXml rangeOfString:tagFin];
        NSRange subStringRange = NSMakeRange(startRange.location+[tagInicio length],
                                             endRange.location - (startRange.location+startRange.length));
        subString = [elXml substringWithRange:subStringRange];
    }
    @catch (NSException *exception) {
        subString = @"";
    }
    @finally {
        return subString;
    }
}

@end
