//
//  MainViewController.h
//  SuiteMCommerceDemo
//
//  Created by Pruebas MIT Desarrollo on 22/02/16.
//  Copyright © 2016 Mercadotecnia Ideas y Tecnología. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PayViewController.h"
#import "BSKeyboardControls.h"
#import "DatosDePrueba.h"

@interface MainViewController : UIViewController <SuiteControllerDelegate, UITextFieldDelegate, BSKeyboardControlsDelegate>

@property (weak, nonatomic) IBOutlet UITextField *textFieldOneClickAmount;
@property (weak, nonatomic) IBOutlet UITextField *textFieldOneClickReference;
@property (weak, nonatomic) IBOutlet UITextField *textFieldOneClickToken;
@property (nonatomic, strong) BSKeyboardControls *keyboardControls;

- (IBAction)btnPay:(id)sender;
- (IBAction)btnTokenize:(id)sender;
- (IBAction)btnPayOneClick:(id)sender;

@end
