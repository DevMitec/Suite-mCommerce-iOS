//
//  Constants.h
//  SuiteMCommerceDemo
//
//  Created by Pruebas MIT Desarrollo on 24/02/16.
//  Copyright © 2016 Mercadotecnia Ideas y Tecnología. All rights reserved.
//

#ifndef Constants_h
#define Constants_h


#pragma mark - WEBPAY

#define WEBPAY_KEY            @"llenar"
#define WEBPAY_COMPANY        @"llenar"
#define WEBPAY_XMLM           @"llenar"

#define WEBPAY_KEY_QA          @"llenar"
#define WEBPAY_COMPANY_QA      @"llenar"
#define WEBPAY_XMLM_QA           @"llenar"

#pragma mark - AUTH

#define AUTH_KEY            @"516883575148515057485348"
#define AUTH_COMPANY        @"SX001"
#define AUTH_BRANCH         @"0001"
#define AUTH_COUNTRY        @"MEX"
#define AUTH_USER           @"SNDBXUS3R"
#define AUTH_PASSWORD       @"SNDBXP44S"
#define AUTH_MERCHANT_C     @"123456"
#define AUTH_TP_OPERATION   @"30"
#define AUTH_CRYPTO         @"3"
#define AUTH_TYPE           @"V/MC"
#define AUTH_CURRENCY       @"MXN"

#define WEBPAY_KEY_SANDBOX  @"53616E64626f78537569746532303136"

#endif /* Constants_h */
