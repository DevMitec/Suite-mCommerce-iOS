//
//  NSData+AES.h
//  AESEncryptionDemo
//

//

#import <Foundation/Foundation.h>

@interface NSData (AES)
-(NSString*) encryptAES:(NSData*)key;
-(NSString*) decryptAES:(NSData*)key;
-(NSString *)base64Encoding;
+ (NSData *)dataWithBase64EncodedStr:(NSString *)string;
+ (NSData *) tripleDesEncryptString:(NSString *)input
                               key:(NSString *)key
                             error:(NSError **)error;
+ (NSString*)tripleDesDecryptData:(NSData *)input
                               key:(NSString *)key
                             error:(NSError **)error;
+ (NSData *)random128BitAESKey;

@end
