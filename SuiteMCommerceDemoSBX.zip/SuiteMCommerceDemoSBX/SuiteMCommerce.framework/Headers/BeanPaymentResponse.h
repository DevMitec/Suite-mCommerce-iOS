//
//  BeanPaymentResponse.h
//  SuiteMCommerce
//
//  Created by Pruebas MIT Desarrollo on 16/02/16.
//  Copyright © 2016 Mercadotecnia Ideas y Tecnología. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BeanPaymentResponse : NSObject

@property (strong, nonatomic) NSString *response;
/*@property (strong, nonatomic) NSString *referencia;
@property (strong, nonatomic) NSString *response;
@property (strong, nonatomic) NSString *aut;
@property (strong, nonatomic) NSString *error;
@property (strong, nonatomic) NSString *ccName;
@property (strong, nonatomic) NSString *ccNum;
@property (strong, nonatomic) NSString *amount;
@property (strong, nonatomic) NSString *type;*/

@end
