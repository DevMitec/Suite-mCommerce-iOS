//
//  SuiteMCommerce.h
//  SuiteMCommerce
//
//  Created by Pruebas MIT Desarrollo on 15/02/16.
//  Copyright © 2016 Mercadotecnia Ideas y Tecnología. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for SuiteMCommerce.
FOUNDATION_EXPORT double SuiteMCommerceVersionNumber;

//! Project version string for SuiteMCommerce.
FOUNDATION_EXPORT const unsigned char SuiteMCommerceVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SuiteMCommerce/PublicHeader.h>

#import <SuiteMCommerce/SuiteController.h>