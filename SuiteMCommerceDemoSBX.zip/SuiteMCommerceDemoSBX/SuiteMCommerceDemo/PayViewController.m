//
//  ViewController.m
//  SuiteMCommerceDemo
//
//  Created by Pruebas MIT Desarrollo on 15/02/16.
//  Copyright © 2016 Mercadotecnia Ideas y Tecnología. All rights reserved.
//

#import "PayViewController.h"
#import "NSData+AES.h"
#import "NSString+AES.h"

@interface PayViewController ()

@end

@implementation PayViewController
SuiteController* controller;
NSString* company;
NSString* xmlm;
NSString* apiKey;

- (void)viewDidLoad {
    [super viewDidLoad];
    controller = [DatosDePrueba getSuiteControllerOnVC:self delegate:self];
    company =  [DatosDePrueba getCompanyWebPay];
    xmlm =  [DatosDePrueba getXmlmWebPay];
    apiKey =  [DatosDePrueba apiKeyWebPay];
}

- (void)viewDidAppear:(BOOL)animated{
}

-(void)viewWillAppear:(BOOL)animated{
    _textFieldAmount.text = @"";
    _textFieldReference.text = @"";
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (IBAction)btnPay:(id)sender {
    if([_textFieldAmount.text length] == 0){
        [self showAlert:@"El monto es requerido"];
        return;
    }
    if([_textFieldReference.text length] == 0){
        [self showAlert:@"La referencia es requerido"];
        return;
    }
    NSString* xmla = [self generaXmlACifradowithAmount:[_textFieldAmount text] reference:[_textFieldReference text]];
    [controller sndPayWithCompany:company xmlA:xmla xmlM:xmlm];
}

-(NSString*) generaXmlACifradowithAmount:(NSString*) amount reference:(NSString*) reference{
    NSString* paymentType = @"C";
    switch ([_SegmentedControlPaymentType selectedSegmentIndex]) {
        case 0:
            paymentType = @"C";
            break;
        case 1:
            paymentType = @"3M";
            break;
        case 2:
            paymentType = @"6M";
            break;
        case 3:
            paymentType = @"9M";
            break;
        case 4:
            paymentType = @"12M";
            break;
        default:
            break;
    }
    NSString* currency = @"MXN";
    switch ([_SegmentedControlPaymentType selectedSegmentIndex]) {
        case 0:
            currency = @"MXN";
            break;
        case 1:
            currency = @"USD";
            break;
        default:
            break;
    }
    NSString* xmla = [self generaXMLAwithtpPago:paymentType
                                         amount:amount
                                    urlResponse:@"https://suitemcommerce.com"
                                     referencia:reference
                                         moneda:currency
                                      date_hour:[self getDateHour]];
    xmla = [xmla encryptAES: apiKey];
    xmla = [xmla stringToHexString];
    return xmla;
}

- (NSString*) generaXMLAwithtpPago:(NSString*) tpPago
                            amount:(NSString*) amount
                       urlResponse:(NSString*) urlResponse
                        referencia:(NSString*) referencia
                            moneda:(NSString*) moneda
                         date_hour:(NSString*) date_hour{
    return [NSString stringWithFormat:
            @"<xml><tpPago>%@</tpPago><amount>%@</amount><urlResponse>%@</urlResponse><referencia>%@</referencia><moneda>%@</moneda><date_hour>%@</date_hour>",
            tpPago,
            amount,
            urlResponse,
            referencia,
            moneda,
            date_hour];
}

- (NSString*) getDateHour{
    NSDate *currentDate = [[NSDate alloc] init];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    NSTimeZone *timeZone = [NSTimeZone localTimeZone];
    [dateFormatter setTimeZone:timeZone];
    [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ssZ"];
    NSString *localDateString = [dateFormatter stringFromDate:currentDate];
    localDateString = [NSString stringWithFormat:@"%@:%@", [localDateString substringToIndex:22], [localDateString substringFromIndex:22]];
    return localDateString;
}



-(void)didFinishAuthenticationProcess:(BeanTokenizeResponse*) tokenizeResponse error:(SuiteError*) error{}
-(void)didFinishTokenizeTransantion:(BeanPaymentWithToken*) beanPaymentWithToken error:(SuiteError*) error{}

-(void)didFinishPayProcess:(NSString *)response error:(SuiteError *)error{
    if(error == nil){
        PaymentResultViewController *paymentResultViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"PaymentResultViewController"];
        NSLog(@"response: %@", response);
        response = [response decryptAES:apiKey];
        NSLog(@"response: %@", response);
        paymentResultViewController.response = response;
        [self presentViewController:paymentResultViewController animated:YES completion:nil];
    }
    else{
        [self showAlert:[error getDescription]];
    }
}

- (void) operationCanceledByUser{
}

- (void) showAlert:(NSString*) message{
    UIAlertController * alert=   [UIAlertController
                                  alertControllerWithTitle:@"Suite MCommerce Demo"
                                  message:message
                                  preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){
        [alert dismissViewControllerAnimated:YES completion:nil];
    }];
    [alert addAction:okAction];
    [self presentViewController:alert animated:NO completion:nil];
}

- (IBAction)btnBack:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}

@end
