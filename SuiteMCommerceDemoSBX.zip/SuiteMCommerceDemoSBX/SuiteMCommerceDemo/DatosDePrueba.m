//
//  DatosDePrueba.m
//  SuiteMCommerceDemo
//
//  Created by Pruebas MIT Desarrollo on 27/04/16.
//  Copyright © 2016 Mercadotecnia Ideas y Tecnología. All rights reserved.
//

#import "DatosDePrueba.h"

@implementation DatosDePrueba

Environment environment = EnvironmentSANDBOX;

+ (SuiteController*) getSuiteControllerOnVC:(UIViewController*) vc delegate:(id<SuiteControllerDelegate>) delgate{
    return [[SuiteController alloc] initOnEnvironment: environment
                                currentViewController: vc
                                             delegate: delgate];
}

+ (BeanTokenization*) getBeanTokenization{
    BeanTokenization *beanTokenization  = [[BeanTokenization alloc] init];
    if(environment == EnvironmentSANDBOX){
        [beanTokenization setBranch:@"0001"];
        [beanTokenization setCompany:@"SX001"];
        [beanTokenization setCountry:@"MEX"];
        [beanTokenization setUser:@"SNDBXUS3R"];
        [beanTokenization setPassword:@"SNDBXP44S"];
        [beanTokenization setMerchant:@"123456"];
        [beanTokenization setCurrency:CurrencyMXN];
        [beanTokenization setOperationType:@"6"];
    }
    else if(environment == EnvironmentQA){
        [beanTokenization setBranch:@""];
        [beanTokenization setCompany:@""];
        [beanTokenization setCountry:@"MEX"];
        [beanTokenization setUser:@""];
        [beanTokenization setPassword:@""];
        [beanTokenization setMerchant:@""];
        [beanTokenization setCurrency:CurrencyMXN];
        [beanTokenization setOperationType:@"6"];
    }
    else if(environment == EnvironmentPROD){
        [beanTokenization setBranch:@""];
        [beanTokenization setCompany:@""];
        [beanTokenization setCountry:@"MEX"];
        [beanTokenization setUser:@""];
        [beanTokenization setPassword:@""];
        [beanTokenization setMerchant:@""];
        [beanTokenization setCurrency:CurrencyMXN];
        [beanTokenization setOperationType:@"6"];
    }
    return beanTokenization;
}

+ (Bean3DS*) getBean3DS{
    Bean3DS *bean3DS = [[Bean3DS alloc] init];
    if(environment == EnvironmentSANDBOX){
        [bean3DS setBranch:@"0001"];
        [bean3DS setCompany:@"SX001"];
        [bean3DS setCountry:@"MEX"];
        [bean3DS setUser:@"SNDBXUS3R"];
        [bean3DS setPassword:@"SNDBXP44S"];
        [bean3DS setMerchant:@"123456"];
        [bean3DS setCurrency:CurrencyMXN];
        [bean3DS setAuthKey:@"516883575148515057485348"];
    }
    else if(environment == EnvironmentQA){
        [bean3DS setBranch:@""];
        [bean3DS setCompany:@""];
        [bean3DS setCountry:@"MEX"];
        [bean3DS setUser:@""];
        [bean3DS setPassword:@""];
        [bean3DS setMerchant:@""];
        [bean3DS setCurrency:CurrencyMXN];
        [bean3DS setAuthKey:@""];
    }
    else if(environment == EnvironmentPROD){
        [bean3DS setBranch:@""];
        [bean3DS setCompany:@""];
        [bean3DS setCountry:@"MEX"];
        [bean3DS setUser:@""];
        [bean3DS setPassword:@""];
        [bean3DS setMerchant:@""];
        [bean3DS setCurrency:CurrencyMXN];
        [bean3DS setAuthKey:@""];
    }
    return bean3DS;
}

+ (NSString*) getCompanyWebPay{
    if(environment == EnvironmentSANDBOX){
        return @"SX001";
    }
    else if(environment == EnvironmentQA){
        return @"";
    }
    else if(environment == EnvironmentPROD){
        return @"";
    }
    return @"";
}
+ (NSString*) getXmlmWebPay{
    if(environment == EnvironmentSANDBOX){
        return @"5647586E6A376D4C4A384452524F43744E424152362B4147524167SNDBX4646C305554677254515145657574623445783768725A3774694869365A6E6A6C716D56556B6F44362F7848634D410A363562674B50SNDBXC7643776F2F6C714C314A6F70326F36784E66644D2F6E64686367595278337434336D3567576E657971414554306A6B467378703071683669595SNDBX6770374C6855620A4433514F6A5A7166574371326A3041505536364C78326838342F762F356756592F6B61562B564A796938646F664F50372FSNDBX7325532483064616F53513D3D";
    }
    else if(environment == EnvironmentQA){
        return @"";
    }
    else if(environment == EnvironmentPROD){
        return @"";
    }
    return @"";
}

+ (NSString*) apiKeyWebPay{
    if(environment == EnvironmentSANDBOX){
        return @"0DC5320E6EC7A484B0B0841CBE26EF08";
    }
    else if(environment == EnvironmentQA){
        return @"";
    }
    else if(environment == EnvironmentPROD){
        return @"";
    }
    return @"";
}

@end
