//
//  PaymentResultViewController.h
//  SuiteMCommerceDemo
//
//  Created by Pruebas MIT Desarrollo on 16/02/16.
//  Copyright © 2016 Mercadotecnia Ideas y Tecnología. All rights reserved.
//

#import "PayViewController.h"
#import <SuiteMCommerce/SuiteMCommerce.h>

@interface PaymentResultViewController : UIViewController

@property (strong, nonatomic) NSString *response;

@property (weak, nonatomic) IBOutlet UILabel *labelReference;
@property (weak, nonatomic) IBOutlet UILabel *labelResponse;
@property (weak, nonatomic) IBOutlet UILabel *labelAuth;
@property (weak, nonatomic) IBOutlet UILabel *labelCcName;
@property (weak, nonatomic) IBOutlet UILabel *labelCcNum;
@property (weak, nonatomic) IBOutlet UILabel *labelCcType;
@property (weak, nonatomic) IBOutlet UILabel *labelAmount;
@property (weak, nonatomic) IBOutlet UITextView *labelError;

- (IBAction)btnBack:(id)sender;

@end
