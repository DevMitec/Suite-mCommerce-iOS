//
//  NSString+AES.m
//  AESEncryptionDemo
//

//

#import "NSString+AES.h"
#import "NSData+AES.h"

@implementation NSString (AES)

-(NSString*) encryptAES:(NSString*)key{
    NSData *plainData= [self dataUsingEncoding:NSUTF8StringEncoding];
    NSString *encryptedString = [plainData encryptAES:[key parseHexBinary]];
    return encryptedString;
}

-(NSString*) decryptAES:(NSString*)key{
    NSData *plainData = [NSData dataWithBase64EncodedStr:self];
    NSString *encryptedString = [plainData decryptAES:[key parseHexBinary]];
    return encryptedString;
}

-(NSData*) parseHexBinary{
    NSString *string = [self stringByReplacingOccurrencesOfString:@" " withString:@""];
    NSMutableData *result= [[NSMutableData alloc] init];
    unsigned char whole_byte;
    char byte_chars[3] = {'\0','\0','\0'};
    int i;
    for (i=0; i < [string length]/2; i++) {
        byte_chars[0] = [string characterAtIndex:i*2];
        byte_chars[1] = [string characterAtIndex:i*2+1];
        whole_byte = strtol(byte_chars, NULL, 16);
        [result appendBytes:&whole_byte length:1];
    }
    return result;
}

- (NSString *)urlencode {
    NSMutableString *output = [NSMutableString string];
    const unsigned char *source = (const unsigned char *)[self UTF8String];
    int sourceLen = strlen((const char *)source);
    for (int i = 0; i < sourceLen; ++i) {
        const unsigned char thisChar = source[i];
        if (thisChar == ' '){
            [output appendString:@"+"];
        } else if (thisChar == '.' || thisChar == '-' || thisChar == '_' || thisChar == '~' ||
                   (thisChar >= 'a' && thisChar <= 'z') ||
                   (thisChar >= 'A' && thisChar <= 'Z') ||
                   (thisChar >= '0' && thisChar <= '9')) {
            [output appendFormat:@"%c", thisChar];
        } else {
            [output appendFormat:@"%%%02X", thisChar];
        }
    }
    return output;
}

- (NSString*) stringToHexString{
    NSString * str = self;
    
    NSString * hexStr = [NSString stringWithFormat:@"%@",
                         [NSData dataWithBytes:[str cStringUsingEncoding:NSUTF8StringEncoding]
                                        length:strlen([str cStringUsingEncoding:NSUTF8StringEncoding])]];
    
    for(NSString * toRemove in [NSArray arrayWithObjects:@"<", @">", @" ", nil])
        hexStr = [hexStr stringByReplacingOccurrencesOfString:toRemove withString:@""];
    
    return hexStr;
}

- (NSString *) stringFromHex
{
    NSString* str = self;
    NSMutableData *stringData = [[NSMutableData alloc] init];
    unsigned char whole_byte;
    char byte_chars[3] = {'\0','\0','\0'};
    int i;
    for (i=0; i < [str length] / 2; i++) {
        byte_chars[0] = [str characterAtIndex:i*2];
        byte_chars[1] = [str characterAtIndex:i*2+1];
        whole_byte = strtol(byte_chars, NULL, 16);
        [stringData appendBytes:&whole_byte length:1];
    }
    return [[NSString alloc] initWithData:stringData encoding:NSASCIIStringEncoding];
}

- (NSString *) padString{
    NSString *str = self;
    
    
    //int padLength = 8 - [str length] % 8;
    
    int add = 8-[str length]%8;
    if (add > 0) {
        NSString *pad = [[NSString string] stringByPaddingToLength:add withString:@" " startingAtIndex:0];
        str = [str stringByAppendingString:pad];
    }
    return str;
}


@end
