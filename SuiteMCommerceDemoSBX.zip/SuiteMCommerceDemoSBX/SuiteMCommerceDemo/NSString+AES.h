//
//  NSString+AES.h
//  AESEncryptionDemo

//

#import <Foundation/Foundation.h>
#import "NSData+AES.h"

@interface NSString (AES)
-(NSString*) decryptAES:(NSString*)key;
-(NSString*) encryptAES:(NSString*)key;
-(NSData*) parseHexBinary;
- (NSString *)urlencode;
- (NSString*) stringToHexString;
- (NSString *) stringFromHex;
- (NSString *) padString;
@end
