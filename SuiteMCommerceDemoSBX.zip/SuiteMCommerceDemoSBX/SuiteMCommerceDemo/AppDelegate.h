//
//  AppDelegate.h
//  SuiteMCommerceDemo
//
//  Created by Pruebas MIT Desarrollo on 15/02/16.
//  Copyright © 2016 Mercadotecnia Ideas y Tecnología. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

