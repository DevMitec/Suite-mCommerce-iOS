//
//  MainViewController.m
//  SuiteMCommerceDemo
//
//  Created by Pruebas MIT Desarrollo on 22/02/16.
//  Copyright © 2016 Mercadotecnia Ideas y Tecnología. All rights reserved.
//

#import "MainViewController.h"

@interface MainViewController ()

@end

@implementation MainViewController

SuiteController* suiteController;
Bean3DS *bean3DS;
BeanTokenization *beanTokenization;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSArray *fields = @[ _textFieldOneClickAmount, _textFieldOneClickReference, _textFieldOneClickToken];
    [self setKeyboardControls:[[BSKeyboardControls alloc] initWithFields:fields]];
    [[self keyboardControls] setDelegate:self];
    
    suiteController = [DatosDePrueba getSuiteControllerOnVC:self delegate:self];
    bean3DS = [DatosDePrueba getBean3DS];
    beanTokenization  = [DatosDePrueba getBeanTokenization];
}

-(void)viewWillAppear:(BOOL)animated{
    _textFieldOneClickReference.text = @"";
    _textFieldOneClickAmount.text = @"";
    _textFieldOneClickToken.text = @"";
}

- (NSString*) stringToHexString:(NSString*) str{
    
    NSString * hexStr = [NSString stringWithFormat:@"%@",
                         [NSData dataWithBytes:[str cStringUsingEncoding:NSUTF8StringEncoding]
                                        length:strlen([str cStringUsingEncoding:NSUTF8StringEncoding])]];
    
    for(NSString * toRemove in [NSArray arrayWithObjects:@"<", @">", @" ", nil])
        hexStr = [hexStr stringByReplacingOccurrencesOfString:toRemove withString:@""];
    
    return hexStr;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (IBAction)btnPay:(id)sender {
    PayViewController *payViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"PayViewController"];
    [self presentViewController:payViewController animated:YES completion:nil];
}

- (IBAction)btnTokenize:(id)sender {
    [suiteController AuthenticateWithBeanTokenization:beanTokenization
                                              bean3DS:bean3DS];
    
}

- (IBAction)btnPayOneClick:(id)sender {
    
    if([[_textFieldOneClickAmount text] isEqualToString:@""] ||
       [[_textFieldOneClickReference text] isEqualToString:@""] ||
       [[_textFieldOneClickToken text] isEqualToString:@""]){
        [self showAlert:@"LLena todos los campos para poder continuar."];
        return;
    }
    
    [beanTokenization setAmount:[_textFieldOneClickAmount text]];
    [beanTokenization setReference:[_textFieldOneClickReference text]];
    [beanTokenization setToken:[_textFieldOneClickToken text]];
    [suiteController sndPayWithTokenWithBeanTokenization:beanTokenization
                                              bean3DS:bean3DS];
}

-(void)didFinishPayProcess:(NSString *)response error:(SuiteError *)error{
    
}

-(void)didFinishAuthenticationProcess:(BeanTokenizeResponse*) tokenizeResponse error:(SuiteError*) error{
    _textFieldOneClickReference.text = @"";
    _textFieldOneClickAmount.text = @"";
    _textFieldOneClickToken.text = @"";
    if(tokenizeResponse){
        [self showAlert:tokenizeResponse.token];
    }
    else{
        [self showAlert:[NSString stringWithFormat:@"Error\n\nCode: %@\nDesc: %@", [error getCode], [error getDescription]]];
    }
}

-(void)didFinishTokenizeTransantion:(BeanPaymentWithToken*) beanPaymentWithToken error:(SuiteError*) error{
    _textFieldOneClickReference.text = @"";
    _textFieldOneClickAmount.text = @"";
    _textFieldOneClickToken.text = @"";
    if(beanPaymentWithToken){
        NSString* msg = [NSString stringWithFormat:@"Response: %@\nFolioPagos: %@\nReferencia: %@\nImporte: %@",
                         beanPaymentWithToken.response,
                         beanPaymentWithToken.folio,
                         beanPaymentWithToken.reference,
                         beanPaymentWithToken.amount];
        
        [self showAlert:msg];
    }
    else{
        [self showAlert:[NSString stringWithFormat:@"Error\n\nCode: %@\nDesc: %@", [error getCode], [error getDescription]]];
    }
}

- (void) operationCanceledByUser{
    _textFieldOneClickReference.text = @"";
    _textFieldOneClickAmount.text = @"";
    _textFieldOneClickToken.text = @"";
}

- (void) showAlert:(NSString*) message{
    UIAlertController * alert=   [UIAlertController
                                  alertControllerWithTitle:@"Suite MCommerce Demo"
                                  message:message
                                  preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){
        [alert dismissViewControllerAnimated:YES completion:nil];
    }];
    [alert addAction:okAction];
    UIViewController *vc = [[[[UIApplication sharedApplication] delegate] window] rootViewController];
    [vc presentViewController:alert animated:YES completion:nil];
}

#pragma mark - Text field delegates

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    [self.keyboardControls setActiveField:textField];
}

#pragma mark -
#pragma mark Text View Delegate

- (void)textViewDidBeginEditing:(UITextView *)textView
{
    [self.keyboardControls setActiveField:textView];
}



#pragma mark Keyboard Controls Delegate

- (void)keyboardControls:(BSKeyboardControls *)keyboardControls directionPressed:(BSKeyboardControlsDirection)direction{}

- (void)keyboardControlsDonePressed:(BSKeyboardControls *)keyboardControls{
    [[self.keyboardControls activeField] resignFirstResponder];
}

@end
