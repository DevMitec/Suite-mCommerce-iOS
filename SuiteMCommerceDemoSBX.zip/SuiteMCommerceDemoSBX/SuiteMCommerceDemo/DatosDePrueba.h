//
//  DatosDePrueba.h
//  SuiteMCommerceDemo
//
//  Created by Pruebas MIT Desarrollo on 27/04/16.
//  Copyright © 2016 Mercadotecnia Ideas y Tecnología. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <SuiteMCommerce/SuiteMCommerce.h>

@interface DatosDePrueba : NSObject

+ (SuiteController*) getSuiteControllerOnVC:(UIViewController*) vc delegate:(id<SuiteControllerDelegate>) delgate;
+ (BeanTokenization*) getBeanTokenization;
+ (Bean3DS*) getBean3DS;
+ (NSString*) getCompanyWebPay;
+ (NSString*) getXmlmWebPay;
+ (NSString*) apiKeyWebPay;
@end
